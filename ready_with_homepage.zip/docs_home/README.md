# Homepage + Pages for GitHub Pages

This package includes a top-level `index.html` that links to all exported Stitch pages.
It also auto-redirects to a default page after 2 seconds.

## Deploy
1. Copy everything in this `docs/` folder into your repo's `docs/` path and commit.
2. Settings → Pages → Deploy from a branch → `main` / `/docs`.
3. Open your Pages URL.

You can change the default redirect target inside `index.html` (look for `<meta http-equiv="refresh" ...>`).